#pragma once

#if UNITY_IOS
#include "UnityViewControllerBaseiOS.h"
#elif UNITY_TVOS
#include "UnityViewControllerBaseTV.h"
#endif
