﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"





extern "C" void Context_t2636657155_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Context_t2636657155_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Context_t2636657155_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Context_t2636657155_0_0_0;
extern "C" void Escape_t169451053_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Escape_t169451053_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Escape_t169451053_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Escape_t169451053_0_0_0;
extern "C" void PreviousInfo_t581002487_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void PreviousInfo_t581002487_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void PreviousInfo_t581002487_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType PreviousInfo_t581002487_0_0_0;
extern "C" void DelegatePInvokeWrapper_AppDomainInitializer_t3898244613();
extern const Il2CppType AppDomainInitializer_t3898244613_0_0_0;
extern "C" void DelegatePInvokeWrapper_Swapper_t2637371637();
extern const Il2CppType Swapper_t2637371637_0_0_0;
extern "C" void DictionaryEntry_t3048875398_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void DictionaryEntry_t3048875398_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void DictionaryEntry_t3048875398_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType DictionaryEntry_t3048875398_0_0_0;
extern "C" void Slot_t2022531261_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Slot_t2022531261_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Slot_t2022531261_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Slot_t2022531261_0_0_0;
extern "C" void Slot_t2267560602_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Slot_t2267560602_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Slot_t2267560602_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Slot_t2267560602_0_0_0;
extern "C" void Enum_t2459695545_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Enum_t2459695545_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Enum_t2459695545_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Enum_t2459695545_0_0_0;
extern "C" void DelegatePInvokeWrapper_ReadDelegate_t3184826381();
extern const Il2CppType ReadDelegate_t3184826381_0_0_0;
extern "C" void DelegatePInvokeWrapper_WriteDelegate_t489908132();
extern const Il2CppType WriteDelegate_t489908132_0_0_0;
extern "C" void MonoIOStat_t1621921065_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoIOStat_t1621921065_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoIOStat_t1621921065_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType MonoIOStat_t1621921065_0_0_0;
extern "C" void MonoEnumInfo_t2335995564_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoEnumInfo_t2335995564_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoEnumInfo_t2335995564_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType MonoEnumInfo_t2335995564_0_0_0;
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType CustomAttributeNamedArgument_t94157543_0_0_0;
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType CustomAttributeTypedArgument_t1498197914_0_0_0;
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ILTokenInfo_t149559338_0_0_0;
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType MonoEventInfo_t2190036573_0_0_0;
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType MonoMethodInfo_t3646562144_0_0_0;
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType MonoPropertyInfo_t486106184_0_0_0;
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ParameterModifier_t1820634920_0_0_0;
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ResourceCacheItem_t333236149_0_0_0;
extern "C" void ResourceInfo_t3933049236_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceInfo_t3933049236_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceInfo_t3933049236_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ResourceInfo_t3933049236_0_0_0;
extern "C" void DelegatePInvokeWrapper_CrossContextDelegate_t754146990();
extern const Il2CppType CrossContextDelegate_t754146990_0_0_0;
extern "C" void DelegatePInvokeWrapper_CallbackHandler_t362827733();
extern const Il2CppType CallbackHandler_t362827733_0_0_0;
extern "C" void SerializationEntry_t3485203212_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SerializationEntry_t3485203212_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SerializationEntry_t3485203212_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType SerializationEntry_t3485203212_0_0_0;
extern "C" void StreamingContext_t1417235061_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void StreamingContext_t1417235061_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void StreamingContext_t1417235061_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType StreamingContext_t1417235061_0_0_0;
extern "C" void DSAParameters_t1872138834_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void DSAParameters_t1872138834_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void DSAParameters_t1872138834_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType DSAParameters_t1872138834_0_0_0;
extern "C" void RSAParameters_t1462703416_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RSAParameters_t1462703416_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RSAParameters_t1462703416_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType RSAParameters_t1462703416_0_0_0;
extern "C" void SecurityFrame_t1002202659_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SecurityFrame_t1002202659_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SecurityFrame_t1002202659_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType SecurityFrame_t1002202659_0_0_0;
extern "C" void DelegatePInvokeWrapper_ThreadStart_t3437517264();
extern const Il2CppType ThreadStart_t3437517264_0_0_0;
extern "C" void ValueType_t3507792607_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ValueType_t3507792607_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ValueType_t3507792607_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ValueType_t3507792607_0_0_0;
extern "C" void X509ChainStatus_t4278378721_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void X509ChainStatus_t4278378721_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void X509ChainStatus_t4278378721_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType X509ChainStatus_t4278378721_0_0_0;
extern "C" void IntStack_t273560425_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void IntStack_t273560425_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void IntStack_t273560425_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType IntStack_t273560425_0_0_0;
extern "C" void Interval_t2354235237_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Interval_t2354235237_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Interval_t2354235237_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Interval_t2354235237_0_0_0;
extern "C" void DelegatePInvokeWrapper_CostDelegate_t1824458113();
extern const Il2CppType CostDelegate_t1824458113_0_0_0;
extern "C" void UriScheme_t1876590943_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void UriScheme_t1876590943_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void UriScheme_t1876590943_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType UriScheme_t1876590943_0_0_0;
extern "C" void CustomEventData_t1269126727_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomEventData_t1269126727_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomEventData_t1269126727_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType CustomEventData_t1269126727_0_0_0;
extern "C" void UnityAnalyticsHandler_t3238795095_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void UnityAnalyticsHandler_t3238795095_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void UnityAnalyticsHandler_t3238795095_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType UnityAnalyticsHandler_t3238795095_0_0_0;
extern "C" void AnimationCurve_t3306541151_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AnimationCurve_t3306541151_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AnimationCurve_t3306541151_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType AnimationCurve_t3306541151_0_0_0;
extern "C" void AnimationEvent_t2428323300_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AnimationEvent_t2428323300_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AnimationEvent_t2428323300_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType AnimationEvent_t2428323300_0_0_0;
extern "C" void AnimatorTransitionInfo_t2410896200_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AnimatorTransitionInfo_t2410896200_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AnimatorTransitionInfo_t2410896200_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType AnimatorTransitionInfo_t2410896200_0_0_0;
extern "C" void DelegatePInvokeWrapper_LogCallback_t1867914413();
extern const Il2CppType LogCallback_t1867914413_0_0_0;
extern "C" void DelegatePInvokeWrapper_LowMemoryCallback_t642977590();
extern const Il2CppType LowMemoryCallback_t642977590_0_0_0;
extern "C" void AssetBundleRequest_t2674559435_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AssetBundleRequest_t2674559435_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AssetBundleRequest_t2674559435_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType AssetBundleRequest_t2674559435_0_0_0;
extern "C" void AsyncOperation_t3814632279_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AsyncOperation_t3814632279_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AsyncOperation_t3814632279_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType AsyncOperation_t3814632279_0_0_0;
extern "C" void DelegatePInvokeWrapper_PCMReaderCallback_t3007145346();
extern const Il2CppType PCMReaderCallback_t3007145346_0_0_0;
extern "C" void DelegatePInvokeWrapper_PCMSetPositionCallback_t421863554();
extern const Il2CppType PCMSetPositionCallback_t421863554_0_0_0;
extern "C" void DelegatePInvokeWrapper_AudioConfigurationChangeHandler_t3743753033();
extern const Il2CppType AudioConfigurationChangeHandler_t3743753033_0_0_0;
extern "C" void DelegatePInvokeWrapper_WillRenderCanvases_t3522132132();
extern const Il2CppType WillRenderCanvases_t3522132132_0_0_0;
extern "C" void Collision_t2876846408_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Collision_t2876846408_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Collision_t2876846408_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Collision_t2876846408_0_0_0;
extern "C" void ControllerColliderHit_t4070855101_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ControllerColliderHit_t4070855101_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ControllerColliderHit_t4070855101_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ControllerColliderHit_t4070855101_0_0_0;
extern "C" void Coroutine_t2299508840_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Coroutine_t2299508840_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Coroutine_t2299508840_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Coroutine_t2299508840_0_0_0;
extern "C" void CullingGroup_t1091689465_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CullingGroup_t1091689465_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CullingGroup_t1091689465_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType CullingGroup_t1091689465_0_0_0;
extern "C" void DelegatePInvokeWrapper_StateChanged_t2480912210();
extern const Il2CppType StateChanged_t2480912210_0_0_0;
extern "C" void DelegatePInvokeWrapper_DisplaysUpdatedDelegate_t3423469815();
extern const Il2CppType DisplaysUpdatedDelegate_t3423469815_0_0_0;
extern "C" void Event_t3028476042_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Event_t3028476042_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Event_t3028476042_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Event_t3028476042_0_0_0;
extern "C" void DelegatePInvokeWrapper_UnityAction_t4025899511();
extern const Il2CppType UnityAction_t4025899511_0_0_0;
extern "C" void DelegatePInvokeWrapper_FontTextureRebuildCallback_t1272078033();
extern const Il2CppType FontTextureRebuildCallback_t1272078033_0_0_0;
extern "C" void Gradient_t3600583008_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Gradient_t3600583008_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Gradient_t3600583008_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Gradient_t3600583008_0_0_0;
extern "C" void DelegatePInvokeWrapper_WindowFunction_t3486805455();
extern const Il2CppType WindowFunction_t3486805455_0_0_0;
extern "C" void GUIContent_t4210063000_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GUIContent_t4210063000_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GUIContent_t4210063000_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GUIContent_t4210063000_0_0_0;
extern "C" void DelegatePInvokeWrapper_SkinChangedDelegate_t3594822336();
extern const Il2CppType SkinChangedDelegate_t3594822336_0_0_0;
extern "C" void GUIStyle_t1799908754_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GUIStyle_t1799908754_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GUIStyle_t1799908754_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GUIStyle_t1799908754_0_0_0;
extern "C" void GUIStyleState_t3801000545_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GUIStyleState_t3801000545_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GUIStyleState_t3801000545_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GUIStyleState_t3801000545_0_0_0;
extern "C" void HostData_t3480691970_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void HostData_t3480691970_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void HostData_t3480691970_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType HostData_t3480691970_0_0_0;
extern "C" void HumanBone_t1529896151_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void HumanBone_t1529896151_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void HumanBone_t1529896151_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType HumanBone_t1529896151_0_0_0;
extern "C" void Object_t1021602117_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Object_t1021602117_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Object_t1021602117_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Object_t1021602117_0_0_0;
extern "C" void RaycastHit_t87180320_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RaycastHit_t87180320_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RaycastHit_t87180320_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType RaycastHit_t87180320_0_0_0;
extern "C" void RaycastHit2D_t4063908774_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RaycastHit2D_t4063908774_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RaycastHit2D_t4063908774_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType RaycastHit2D_t4063908774_0_0_0;
extern "C" void RectOffset_t3387826427_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RectOffset_t3387826427_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RectOffset_t3387826427_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType RectOffset_t3387826427_0_0_0;
extern "C" void DelegatePInvokeWrapper_UpdatedEventHandler_t3033456180();
extern const Il2CppType UpdatedEventHandler_t3033456180_0_0_0;
extern "C" void ResourceRequest_t2560315377_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceRequest_t2560315377_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceRequest_t2560315377_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ResourceRequest_t2560315377_0_0_0;
extern "C" void ScriptableObject_t1975622470_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ScriptableObject_t1975622470_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ScriptableObject_t1975622470_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ScriptableObject_t1975622470_0_0_0;
extern "C" void HitInfo_t1761367055_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void HitInfo_t1761367055_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void HitInfo_t1761367055_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType HitInfo_t1761367055_0_0_0;
extern "C" void SkeletonBone_t345082847_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SkeletonBone_t345082847_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SkeletonBone_t345082847_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType SkeletonBone_t345082847_0_0_0;
extern "C" void GcAchievementData_t1754866149_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GcAchievementData_t1754866149_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GcAchievementData_t1754866149_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GcAchievementData_t1754866149_0_0_0;
extern "C" void GcAchievementDescriptionData_t960725851_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GcAchievementDescriptionData_t960725851_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GcAchievementDescriptionData_t960725851_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GcAchievementDescriptionData_t960725851_0_0_0;
extern "C" void GcLeaderboard_t453887929_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GcLeaderboard_t453887929_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GcLeaderboard_t453887929_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GcLeaderboard_t453887929_0_0_0;
extern "C" void GcScoreData_t3676783238_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GcScoreData_t3676783238_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GcScoreData_t3676783238_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GcScoreData_t3676783238_0_0_0;
extern "C" void GcUserProfileData_t3198293052_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void GcUserProfileData_t3198293052_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void GcUserProfileData_t3198293052_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType GcUserProfileData_t3198293052_0_0_0;
extern "C" void TextGenerationSettings_t2543476768_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void TextGenerationSettings_t2543476768_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void TextGenerationSettings_t2543476768_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType TextGenerationSettings_t2543476768_0_0_0;
extern "C" void TextGenerator_t647235000_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void TextGenerator_t647235000_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void TextGenerator_t647235000_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType TextGenerator_t647235000_0_0_0;
extern "C" void TrackedReference_t1045890189_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void TrackedReference_t1045890189_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void TrackedReference_t1045890189_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType TrackedReference_t1045890189_0_0_0;
extern "C" void WaitForSeconds_t3839502067_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void WaitForSeconds_t3839502067_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void WaitForSeconds_t3839502067_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType WaitForSeconds_t3839502067_0_0_0;
extern "C" void YieldInstruction_t3462875981_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void YieldInstruction_t3462875981_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void YieldInstruction_t3462875981_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType YieldInstruction_t3462875981_0_0_0;
extern "C" void RaycastResult_t21186376_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RaycastResult_t21186376_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RaycastResult_t21186376_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType RaycastResult_t21186376_0_0_0;
extern "C" void ColorTween_t3438117476_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ColorTween_t3438117476_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ColorTween_t3438117476_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType ColorTween_t3438117476_0_0_0;
extern "C" void FloatTween_t2986189219_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void FloatTween_t2986189219_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void FloatTween_t2986189219_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType FloatTween_t2986189219_0_0_0;
extern "C" void Resources_t2975512894_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Resources_t2975512894_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Resources_t2975512894_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Resources_t2975512894_0_0_0;
extern "C" void DelegatePInvokeWrapper_OnValidateInput_t1946318473();
extern const Il2CppType OnValidateInput_t1946318473_0_0_0;
extern "C" void Navigation_t1571958496_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Navigation_t1571958496_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Navigation_t1571958496_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType Navigation_t1571958496_0_0_0;
extern "C" void SpriteState_t1353336012_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SpriteState_t1353336012_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SpriteState_t1353336012_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const Il2CppType SpriteState_t1353336012_0_0_0;
extern Il2CppInteropData g_Il2CppInteropData[93] = 
{
	{ NULL, Context_t2636657155_marshal_pinvoke, Context_t2636657155_marshal_pinvoke_back, Context_t2636657155_marshal_pinvoke_cleanup, NULL, NULL, &Context_t2636657155_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/Context */,
	{ NULL, Escape_t169451053_marshal_pinvoke, Escape_t169451053_marshal_pinvoke_back, Escape_t169451053_marshal_pinvoke_cleanup, NULL, NULL, &Escape_t169451053_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/Escape */,
	{ NULL, PreviousInfo_t581002487_marshal_pinvoke, PreviousInfo_t581002487_marshal_pinvoke_back, PreviousInfo_t581002487_marshal_pinvoke_cleanup, NULL, NULL, &PreviousInfo_t581002487_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/PreviousInfo */,
	{ DelegatePInvokeWrapper_AppDomainInitializer_t3898244613, NULL, NULL, NULL, NULL, NULL, &AppDomainInitializer_t3898244613_0_0_0 } /* System.AppDomainInitializer */,
	{ DelegatePInvokeWrapper_Swapper_t2637371637, NULL, NULL, NULL, NULL, NULL, &Swapper_t2637371637_0_0_0 } /* System.Array/Swapper */,
	{ NULL, DictionaryEntry_t3048875398_marshal_pinvoke, DictionaryEntry_t3048875398_marshal_pinvoke_back, DictionaryEntry_t3048875398_marshal_pinvoke_cleanup, NULL, NULL, &DictionaryEntry_t3048875398_0_0_0 } /* System.Collections.DictionaryEntry */,
	{ NULL, Slot_t2022531261_marshal_pinvoke, Slot_t2022531261_marshal_pinvoke_back, Slot_t2022531261_marshal_pinvoke_cleanup, NULL, NULL, &Slot_t2022531261_0_0_0 } /* System.Collections.Hashtable/Slot */,
	{ NULL, Slot_t2267560602_marshal_pinvoke, Slot_t2267560602_marshal_pinvoke_back, Slot_t2267560602_marshal_pinvoke_cleanup, NULL, NULL, &Slot_t2267560602_0_0_0 } /* System.Collections.SortedList/Slot */,
	{ NULL, Enum_t2459695545_marshal_pinvoke, Enum_t2459695545_marshal_pinvoke_back, Enum_t2459695545_marshal_pinvoke_cleanup, NULL, NULL, &Enum_t2459695545_0_0_0 } /* System.Enum */,
	{ DelegatePInvokeWrapper_ReadDelegate_t3184826381, NULL, NULL, NULL, NULL, NULL, &ReadDelegate_t3184826381_0_0_0 } /* System.IO.FileStream/ReadDelegate */,
	{ DelegatePInvokeWrapper_WriteDelegate_t489908132, NULL, NULL, NULL, NULL, NULL, &WriteDelegate_t489908132_0_0_0 } /* System.IO.FileStream/WriteDelegate */,
	{ NULL, MonoIOStat_t1621921065_marshal_pinvoke, MonoIOStat_t1621921065_marshal_pinvoke_back, MonoIOStat_t1621921065_marshal_pinvoke_cleanup, NULL, NULL, &MonoIOStat_t1621921065_0_0_0 } /* System.IO.MonoIOStat */,
	{ NULL, MonoEnumInfo_t2335995564_marshal_pinvoke, MonoEnumInfo_t2335995564_marshal_pinvoke_back, MonoEnumInfo_t2335995564_marshal_pinvoke_cleanup, NULL, NULL, &MonoEnumInfo_t2335995564_0_0_0 } /* System.MonoEnumInfo */,
	{ NULL, CustomAttributeNamedArgument_t94157543_marshal_pinvoke, CustomAttributeNamedArgument_t94157543_marshal_pinvoke_back, CustomAttributeNamedArgument_t94157543_marshal_pinvoke_cleanup, NULL, NULL, &CustomAttributeNamedArgument_t94157543_0_0_0 } /* System.Reflection.CustomAttributeNamedArgument */,
	{ NULL, CustomAttributeTypedArgument_t1498197914_marshal_pinvoke, CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_back, CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_cleanup, NULL, NULL, &CustomAttributeTypedArgument_t1498197914_0_0_0 } /* System.Reflection.CustomAttributeTypedArgument */,
	{ NULL, ILTokenInfo_t149559338_marshal_pinvoke, ILTokenInfo_t149559338_marshal_pinvoke_back, ILTokenInfo_t149559338_marshal_pinvoke_cleanup, NULL, NULL, &ILTokenInfo_t149559338_0_0_0 } /* System.Reflection.Emit.ILTokenInfo */,
	{ NULL, MonoEventInfo_t2190036573_marshal_pinvoke, MonoEventInfo_t2190036573_marshal_pinvoke_back, MonoEventInfo_t2190036573_marshal_pinvoke_cleanup, NULL, NULL, &MonoEventInfo_t2190036573_0_0_0 } /* System.Reflection.MonoEventInfo */,
	{ NULL, MonoMethodInfo_t3646562144_marshal_pinvoke, MonoMethodInfo_t3646562144_marshal_pinvoke_back, MonoMethodInfo_t3646562144_marshal_pinvoke_cleanup, NULL, NULL, &MonoMethodInfo_t3646562144_0_0_0 } /* System.Reflection.MonoMethodInfo */,
	{ NULL, MonoPropertyInfo_t486106184_marshal_pinvoke, MonoPropertyInfo_t486106184_marshal_pinvoke_back, MonoPropertyInfo_t486106184_marshal_pinvoke_cleanup, NULL, NULL, &MonoPropertyInfo_t486106184_0_0_0 } /* System.Reflection.MonoPropertyInfo */,
	{ NULL, ParameterModifier_t1820634920_marshal_pinvoke, ParameterModifier_t1820634920_marshal_pinvoke_back, ParameterModifier_t1820634920_marshal_pinvoke_cleanup, NULL, NULL, &ParameterModifier_t1820634920_0_0_0 } /* System.Reflection.ParameterModifier */,
	{ NULL, ResourceCacheItem_t333236149_marshal_pinvoke, ResourceCacheItem_t333236149_marshal_pinvoke_back, ResourceCacheItem_t333236149_marshal_pinvoke_cleanup, NULL, NULL, &ResourceCacheItem_t333236149_0_0_0 } /* System.Resources.ResourceReader/ResourceCacheItem */,
	{ NULL, ResourceInfo_t3933049236_marshal_pinvoke, ResourceInfo_t3933049236_marshal_pinvoke_back, ResourceInfo_t3933049236_marshal_pinvoke_cleanup, NULL, NULL, &ResourceInfo_t3933049236_0_0_0 } /* System.Resources.ResourceReader/ResourceInfo */,
	{ DelegatePInvokeWrapper_CrossContextDelegate_t754146990, NULL, NULL, NULL, NULL, NULL, &CrossContextDelegate_t754146990_0_0_0 } /* System.Runtime.Remoting.Contexts.CrossContextDelegate */,
	{ DelegatePInvokeWrapper_CallbackHandler_t362827733, NULL, NULL, NULL, NULL, NULL, &CallbackHandler_t362827733_0_0_0 } /* System.Runtime.Serialization.SerializationCallbacks/CallbackHandler */,
	{ NULL, SerializationEntry_t3485203212_marshal_pinvoke, SerializationEntry_t3485203212_marshal_pinvoke_back, SerializationEntry_t3485203212_marshal_pinvoke_cleanup, NULL, NULL, &SerializationEntry_t3485203212_0_0_0 } /* System.Runtime.Serialization.SerializationEntry */,
	{ NULL, StreamingContext_t1417235061_marshal_pinvoke, StreamingContext_t1417235061_marshal_pinvoke_back, StreamingContext_t1417235061_marshal_pinvoke_cleanup, NULL, NULL, &StreamingContext_t1417235061_0_0_0 } /* System.Runtime.Serialization.StreamingContext */,
	{ NULL, DSAParameters_t1872138834_marshal_pinvoke, DSAParameters_t1872138834_marshal_pinvoke_back, DSAParameters_t1872138834_marshal_pinvoke_cleanup, NULL, NULL, &DSAParameters_t1872138834_0_0_0 } /* System.Security.Cryptography.DSAParameters */,
	{ NULL, RSAParameters_t1462703416_marshal_pinvoke, RSAParameters_t1462703416_marshal_pinvoke_back, RSAParameters_t1462703416_marshal_pinvoke_cleanup, NULL, NULL, &RSAParameters_t1462703416_0_0_0 } /* System.Security.Cryptography.RSAParameters */,
	{ NULL, SecurityFrame_t1002202659_marshal_pinvoke, SecurityFrame_t1002202659_marshal_pinvoke_back, SecurityFrame_t1002202659_marshal_pinvoke_cleanup, NULL, NULL, &SecurityFrame_t1002202659_0_0_0 } /* System.Security.SecurityFrame */,
	{ DelegatePInvokeWrapper_ThreadStart_t3437517264, NULL, NULL, NULL, NULL, NULL, &ThreadStart_t3437517264_0_0_0 } /* System.Threading.ThreadStart */,
	{ NULL, ValueType_t3507792607_marshal_pinvoke, ValueType_t3507792607_marshal_pinvoke_back, ValueType_t3507792607_marshal_pinvoke_cleanup, NULL, NULL, &ValueType_t3507792607_0_0_0 } /* System.ValueType */,
	{ NULL, X509ChainStatus_t4278378721_marshal_pinvoke, X509ChainStatus_t4278378721_marshal_pinvoke_back, X509ChainStatus_t4278378721_marshal_pinvoke_cleanup, NULL, NULL, &X509ChainStatus_t4278378721_0_0_0 } /* System.Security.Cryptography.X509Certificates.X509ChainStatus */,
	{ NULL, IntStack_t273560425_marshal_pinvoke, IntStack_t273560425_marshal_pinvoke_back, IntStack_t273560425_marshal_pinvoke_cleanup, NULL, NULL, &IntStack_t273560425_0_0_0 } /* System.Text.RegularExpressions.Interpreter/IntStack */,
	{ NULL, Interval_t2354235237_marshal_pinvoke, Interval_t2354235237_marshal_pinvoke_back, Interval_t2354235237_marshal_pinvoke_cleanup, NULL, NULL, &Interval_t2354235237_0_0_0 } /* System.Text.RegularExpressions.Interval */,
	{ DelegatePInvokeWrapper_CostDelegate_t1824458113, NULL, NULL, NULL, NULL, NULL, &CostDelegate_t1824458113_0_0_0 } /* System.Text.RegularExpressions.IntervalCollection/CostDelegate */,
	{ NULL, UriScheme_t1876590943_marshal_pinvoke, UriScheme_t1876590943_marshal_pinvoke_back, UriScheme_t1876590943_marshal_pinvoke_cleanup, NULL, NULL, &UriScheme_t1876590943_0_0_0 } /* System.Uri/UriScheme */,
	{ NULL, CustomEventData_t1269126727_marshal_pinvoke, CustomEventData_t1269126727_marshal_pinvoke_back, CustomEventData_t1269126727_marshal_pinvoke_cleanup, NULL, NULL, &CustomEventData_t1269126727_0_0_0 } /* UnityEngine.Analytics.CustomEventData */,
	{ NULL, UnityAnalyticsHandler_t3238795095_marshal_pinvoke, UnityAnalyticsHandler_t3238795095_marshal_pinvoke_back, UnityAnalyticsHandler_t3238795095_marshal_pinvoke_cleanup, NULL, NULL, &UnityAnalyticsHandler_t3238795095_0_0_0 } /* UnityEngine.Analytics.UnityAnalyticsHandler */,
	{ NULL, AnimationCurve_t3306541151_marshal_pinvoke, AnimationCurve_t3306541151_marshal_pinvoke_back, AnimationCurve_t3306541151_marshal_pinvoke_cleanup, NULL, NULL, &AnimationCurve_t3306541151_0_0_0 } /* UnityEngine.AnimationCurve */,
	{ NULL, AnimationEvent_t2428323300_marshal_pinvoke, AnimationEvent_t2428323300_marshal_pinvoke_back, AnimationEvent_t2428323300_marshal_pinvoke_cleanup, NULL, NULL, &AnimationEvent_t2428323300_0_0_0 } /* UnityEngine.AnimationEvent */,
	{ NULL, AnimatorTransitionInfo_t2410896200_marshal_pinvoke, AnimatorTransitionInfo_t2410896200_marshal_pinvoke_back, AnimatorTransitionInfo_t2410896200_marshal_pinvoke_cleanup, NULL, NULL, &AnimatorTransitionInfo_t2410896200_0_0_0 } /* UnityEngine.AnimatorTransitionInfo */,
	{ DelegatePInvokeWrapper_LogCallback_t1867914413, NULL, NULL, NULL, NULL, NULL, &LogCallback_t1867914413_0_0_0 } /* UnityEngine.Application/LogCallback */,
	{ DelegatePInvokeWrapper_LowMemoryCallback_t642977590, NULL, NULL, NULL, NULL, NULL, &LowMemoryCallback_t642977590_0_0_0 } /* UnityEngine.Application/LowMemoryCallback */,
	{ NULL, AssetBundleRequest_t2674559435_marshal_pinvoke, AssetBundleRequest_t2674559435_marshal_pinvoke_back, AssetBundleRequest_t2674559435_marshal_pinvoke_cleanup, NULL, NULL, &AssetBundleRequest_t2674559435_0_0_0 } /* UnityEngine.AssetBundleRequest */,
	{ NULL, AsyncOperation_t3814632279_marshal_pinvoke, AsyncOperation_t3814632279_marshal_pinvoke_back, AsyncOperation_t3814632279_marshal_pinvoke_cleanup, NULL, NULL, &AsyncOperation_t3814632279_0_0_0 } /* UnityEngine.AsyncOperation */,
	{ DelegatePInvokeWrapper_PCMReaderCallback_t3007145346, NULL, NULL, NULL, NULL, NULL, &PCMReaderCallback_t3007145346_0_0_0 } /* UnityEngine.AudioClip/PCMReaderCallback */,
	{ DelegatePInvokeWrapper_PCMSetPositionCallback_t421863554, NULL, NULL, NULL, NULL, NULL, &PCMSetPositionCallback_t421863554_0_0_0 } /* UnityEngine.AudioClip/PCMSetPositionCallback */,
	{ DelegatePInvokeWrapper_AudioConfigurationChangeHandler_t3743753033, NULL, NULL, NULL, NULL, NULL, &AudioConfigurationChangeHandler_t3743753033_0_0_0 } /* UnityEngine.AudioSettings/AudioConfigurationChangeHandler */,
	{ DelegatePInvokeWrapper_WillRenderCanvases_t3522132132, NULL, NULL, NULL, NULL, NULL, &WillRenderCanvases_t3522132132_0_0_0 } /* UnityEngine.Canvas/WillRenderCanvases */,
	{ NULL, Collision_t2876846408_marshal_pinvoke, Collision_t2876846408_marshal_pinvoke_back, Collision_t2876846408_marshal_pinvoke_cleanup, NULL, NULL, &Collision_t2876846408_0_0_0 } /* UnityEngine.Collision */,
	{ NULL, ControllerColliderHit_t4070855101_marshal_pinvoke, ControllerColliderHit_t4070855101_marshal_pinvoke_back, ControllerColliderHit_t4070855101_marshal_pinvoke_cleanup, NULL, NULL, &ControllerColliderHit_t4070855101_0_0_0 } /* UnityEngine.ControllerColliderHit */,
	{ NULL, Coroutine_t2299508840_marshal_pinvoke, Coroutine_t2299508840_marshal_pinvoke_back, Coroutine_t2299508840_marshal_pinvoke_cleanup, NULL, NULL, &Coroutine_t2299508840_0_0_0 } /* UnityEngine.Coroutine */,
	{ NULL, CullingGroup_t1091689465_marshal_pinvoke, CullingGroup_t1091689465_marshal_pinvoke_back, CullingGroup_t1091689465_marshal_pinvoke_cleanup, NULL, NULL, &CullingGroup_t1091689465_0_0_0 } /* UnityEngine.CullingGroup */,
	{ DelegatePInvokeWrapper_StateChanged_t2480912210, NULL, NULL, NULL, NULL, NULL, &StateChanged_t2480912210_0_0_0 } /* UnityEngine.CullingGroup/StateChanged */,
	{ DelegatePInvokeWrapper_DisplaysUpdatedDelegate_t3423469815, NULL, NULL, NULL, NULL, NULL, &DisplaysUpdatedDelegate_t3423469815_0_0_0 } /* UnityEngine.Display/DisplaysUpdatedDelegate */,
	{ NULL, Event_t3028476042_marshal_pinvoke, Event_t3028476042_marshal_pinvoke_back, Event_t3028476042_marshal_pinvoke_cleanup, NULL, NULL, &Event_t3028476042_0_0_0 } /* UnityEngine.Event */,
	{ DelegatePInvokeWrapper_UnityAction_t4025899511, NULL, NULL, NULL, NULL, NULL, &UnityAction_t4025899511_0_0_0 } /* UnityEngine.Events.UnityAction */,
	{ DelegatePInvokeWrapper_FontTextureRebuildCallback_t1272078033, NULL, NULL, NULL, NULL, NULL, &FontTextureRebuildCallback_t1272078033_0_0_0 } /* UnityEngine.Font/FontTextureRebuildCallback */,
	{ NULL, Gradient_t3600583008_marshal_pinvoke, Gradient_t3600583008_marshal_pinvoke_back, Gradient_t3600583008_marshal_pinvoke_cleanup, NULL, NULL, &Gradient_t3600583008_0_0_0 } /* UnityEngine.Gradient */,
	{ DelegatePInvokeWrapper_WindowFunction_t3486805455, NULL, NULL, NULL, NULL, NULL, &WindowFunction_t3486805455_0_0_0 } /* UnityEngine.GUI/WindowFunction */,
	{ NULL, GUIContent_t4210063000_marshal_pinvoke, GUIContent_t4210063000_marshal_pinvoke_back, GUIContent_t4210063000_marshal_pinvoke_cleanup, NULL, NULL, &GUIContent_t4210063000_0_0_0 } /* UnityEngine.GUIContent */,
	{ DelegatePInvokeWrapper_SkinChangedDelegate_t3594822336, NULL, NULL, NULL, NULL, NULL, &SkinChangedDelegate_t3594822336_0_0_0 } /* UnityEngine.GUISkin/SkinChangedDelegate */,
	{ NULL, GUIStyle_t1799908754_marshal_pinvoke, GUIStyle_t1799908754_marshal_pinvoke_back, GUIStyle_t1799908754_marshal_pinvoke_cleanup, NULL, NULL, &GUIStyle_t1799908754_0_0_0 } /* UnityEngine.GUIStyle */,
	{ NULL, GUIStyleState_t3801000545_marshal_pinvoke, GUIStyleState_t3801000545_marshal_pinvoke_back, GUIStyleState_t3801000545_marshal_pinvoke_cleanup, NULL, NULL, &GUIStyleState_t3801000545_0_0_0 } /* UnityEngine.GUIStyleState */,
	{ NULL, HostData_t3480691970_marshal_pinvoke, HostData_t3480691970_marshal_pinvoke_back, HostData_t3480691970_marshal_pinvoke_cleanup, NULL, NULL, &HostData_t3480691970_0_0_0 } /* UnityEngine.HostData */,
	{ NULL, HumanBone_t1529896151_marshal_pinvoke, HumanBone_t1529896151_marshal_pinvoke_back, HumanBone_t1529896151_marshal_pinvoke_cleanup, NULL, NULL, &HumanBone_t1529896151_0_0_0 } /* UnityEngine.HumanBone */,
	{ NULL, Object_t1021602117_marshal_pinvoke, Object_t1021602117_marshal_pinvoke_back, Object_t1021602117_marshal_pinvoke_cleanup, NULL, NULL, &Object_t1021602117_0_0_0 } /* UnityEngine.Object */,
	{ NULL, RaycastHit_t87180320_marshal_pinvoke, RaycastHit_t87180320_marshal_pinvoke_back, RaycastHit_t87180320_marshal_pinvoke_cleanup, NULL, NULL, &RaycastHit_t87180320_0_0_0 } /* UnityEngine.RaycastHit */,
	{ NULL, RaycastHit2D_t4063908774_marshal_pinvoke, RaycastHit2D_t4063908774_marshal_pinvoke_back, RaycastHit2D_t4063908774_marshal_pinvoke_cleanup, NULL, NULL, &RaycastHit2D_t4063908774_0_0_0 } /* UnityEngine.RaycastHit2D */,
	{ NULL, RectOffset_t3387826427_marshal_pinvoke, RectOffset_t3387826427_marshal_pinvoke_back, RectOffset_t3387826427_marshal_pinvoke_cleanup, NULL, NULL, &RectOffset_t3387826427_0_0_0 } /* UnityEngine.RectOffset */,
	{ DelegatePInvokeWrapper_UpdatedEventHandler_t3033456180, NULL, NULL, NULL, NULL, NULL, &UpdatedEventHandler_t3033456180_0_0_0 } /* UnityEngine.RemoteSettings/UpdatedEventHandler */,
	{ NULL, ResourceRequest_t2560315377_marshal_pinvoke, ResourceRequest_t2560315377_marshal_pinvoke_back, ResourceRequest_t2560315377_marshal_pinvoke_cleanup, NULL, NULL, &ResourceRequest_t2560315377_0_0_0 } /* UnityEngine.ResourceRequest */,
	{ NULL, ScriptableObject_t1975622470_marshal_pinvoke, ScriptableObject_t1975622470_marshal_pinvoke_back, ScriptableObject_t1975622470_marshal_pinvoke_cleanup, NULL, NULL, &ScriptableObject_t1975622470_0_0_0 } /* UnityEngine.ScriptableObject */,
	{ NULL, HitInfo_t1761367055_marshal_pinvoke, HitInfo_t1761367055_marshal_pinvoke_back, HitInfo_t1761367055_marshal_pinvoke_cleanup, NULL, NULL, &HitInfo_t1761367055_0_0_0 } /* UnityEngine.SendMouseEvents/HitInfo */,
	{ NULL, SkeletonBone_t345082847_marshal_pinvoke, SkeletonBone_t345082847_marshal_pinvoke_back, SkeletonBone_t345082847_marshal_pinvoke_cleanup, NULL, NULL, &SkeletonBone_t345082847_0_0_0 } /* UnityEngine.SkeletonBone */,
	{ NULL, GcAchievementData_t1754866149_marshal_pinvoke, GcAchievementData_t1754866149_marshal_pinvoke_back, GcAchievementData_t1754866149_marshal_pinvoke_cleanup, NULL, NULL, &GcAchievementData_t1754866149_0_0_0 } /* UnityEngine.SocialPlatforms.GameCenter.GcAchievementData */,
	{ NULL, GcAchievementDescriptionData_t960725851_marshal_pinvoke, GcAchievementDescriptionData_t960725851_marshal_pinvoke_back, GcAchievementDescriptionData_t960725851_marshal_pinvoke_cleanup, NULL, NULL, &GcAchievementDescriptionData_t960725851_0_0_0 } /* UnityEngine.SocialPlatforms.GameCenter.GcAchievementDescriptionData */,
	{ NULL, GcLeaderboard_t453887929_marshal_pinvoke, GcLeaderboard_t453887929_marshal_pinvoke_back, GcLeaderboard_t453887929_marshal_pinvoke_cleanup, NULL, NULL, &GcLeaderboard_t453887929_0_0_0 } /* UnityEngine.SocialPlatforms.GameCenter.GcLeaderboard */,
	{ NULL, GcScoreData_t3676783238_marshal_pinvoke, GcScoreData_t3676783238_marshal_pinvoke_back, GcScoreData_t3676783238_marshal_pinvoke_cleanup, NULL, NULL, &GcScoreData_t3676783238_0_0_0 } /* UnityEngine.SocialPlatforms.GameCenter.GcScoreData */,
	{ NULL, GcUserProfileData_t3198293052_marshal_pinvoke, GcUserProfileData_t3198293052_marshal_pinvoke_back, GcUserProfileData_t3198293052_marshal_pinvoke_cleanup, NULL, NULL, &GcUserProfileData_t3198293052_0_0_0 } /* UnityEngine.SocialPlatforms.GameCenter.GcUserProfileData */,
	{ NULL, TextGenerationSettings_t2543476768_marshal_pinvoke, TextGenerationSettings_t2543476768_marshal_pinvoke_back, TextGenerationSettings_t2543476768_marshal_pinvoke_cleanup, NULL, NULL, &TextGenerationSettings_t2543476768_0_0_0 } /* UnityEngine.TextGenerationSettings */,
	{ NULL, TextGenerator_t647235000_marshal_pinvoke, TextGenerator_t647235000_marshal_pinvoke_back, TextGenerator_t647235000_marshal_pinvoke_cleanup, NULL, NULL, &TextGenerator_t647235000_0_0_0 } /* UnityEngine.TextGenerator */,
	{ NULL, TrackedReference_t1045890189_marshal_pinvoke, TrackedReference_t1045890189_marshal_pinvoke_back, TrackedReference_t1045890189_marshal_pinvoke_cleanup, NULL, NULL, &TrackedReference_t1045890189_0_0_0 } /* UnityEngine.TrackedReference */,
	{ NULL, WaitForSeconds_t3839502067_marshal_pinvoke, WaitForSeconds_t3839502067_marshal_pinvoke_back, WaitForSeconds_t3839502067_marshal_pinvoke_cleanup, NULL, NULL, &WaitForSeconds_t3839502067_0_0_0 } /* UnityEngine.WaitForSeconds */,
	{ NULL, YieldInstruction_t3462875981_marshal_pinvoke, YieldInstruction_t3462875981_marshal_pinvoke_back, YieldInstruction_t3462875981_marshal_pinvoke_cleanup, NULL, NULL, &YieldInstruction_t3462875981_0_0_0 } /* UnityEngine.YieldInstruction */,
	{ NULL, RaycastResult_t21186376_marshal_pinvoke, RaycastResult_t21186376_marshal_pinvoke_back, RaycastResult_t21186376_marshal_pinvoke_cleanup, NULL, NULL, &RaycastResult_t21186376_0_0_0 } /* UnityEngine.EventSystems.RaycastResult */,
	{ NULL, ColorTween_t3438117476_marshal_pinvoke, ColorTween_t3438117476_marshal_pinvoke_back, ColorTween_t3438117476_marshal_pinvoke_cleanup, NULL, NULL, &ColorTween_t3438117476_0_0_0 } /* UnityEngine.UI.CoroutineTween.ColorTween */,
	{ NULL, FloatTween_t2986189219_marshal_pinvoke, FloatTween_t2986189219_marshal_pinvoke_back, FloatTween_t2986189219_marshal_pinvoke_cleanup, NULL, NULL, &FloatTween_t2986189219_0_0_0 } /* UnityEngine.UI.CoroutineTween.FloatTween */,
	{ NULL, Resources_t2975512894_marshal_pinvoke, Resources_t2975512894_marshal_pinvoke_back, Resources_t2975512894_marshal_pinvoke_cleanup, NULL, NULL, &Resources_t2975512894_0_0_0 } /* UnityEngine.UI.DefaultControls/Resources */,
	{ DelegatePInvokeWrapper_OnValidateInput_t1946318473, NULL, NULL, NULL, NULL, NULL, &OnValidateInput_t1946318473_0_0_0 } /* UnityEngine.UI.InputField/OnValidateInput */,
	{ NULL, Navigation_t1571958496_marshal_pinvoke, Navigation_t1571958496_marshal_pinvoke_back, Navigation_t1571958496_marshal_pinvoke_cleanup, NULL, NULL, &Navigation_t1571958496_0_0_0 } /* UnityEngine.UI.Navigation */,
	{ NULL, SpriteState_t1353336012_marshal_pinvoke, SpriteState_t1353336012_marshal_pinvoke_back, SpriteState_t1353336012_marshal_pinvoke_cleanup, NULL, NULL, &SpriteState_t1353336012_0_0_0 } /* UnityEngine.UI.SpriteState */,
	NULL,
};
