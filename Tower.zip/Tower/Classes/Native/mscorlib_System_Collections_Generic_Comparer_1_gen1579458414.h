﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

#include "mscorlib_System_Object2689449295.h"

// System.Collections.Generic.Comparer`1<System.Object>
struct Comparer_1_t1579458414;




#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Comparer`1<System.Object>
struct  Comparer_1_t1579458414  : public Il2CppObject
{
public:

public:
};

struct Comparer_1_t1579458414_StaticFields
{
public:
	// System.Collections.Generic.Comparer`1<T> System.Collections.Generic.Comparer`1::_default
	Comparer_1_t1579458414 * ____default_0;

public:
	inline static int32_t get_offset_of__default_0() { return static_cast<int32_t>(offsetof(Comparer_1_t1579458414_StaticFields, ____default_0)); }
	inline Comparer_1_t1579458414 * get__default_0() const { return ____default_0; }
	inline Comparer_1_t1579458414 ** get_address_of__default_0() { return &____default_0; }
	inline void set__default_0(Comparer_1_t1579458414 * value)
	{
		____default_0 = value;
		Il2CppCodeGenWriteBarrier(&____default_0, value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
