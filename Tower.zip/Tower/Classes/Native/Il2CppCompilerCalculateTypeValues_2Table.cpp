﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Collections_SortedList3004938869.h"
#include "mscorlib_System_Collections_SortedList_Slot2267560602.h"
#include "mscorlib_System_Collections_SortedList_EnumeratorM4029123303.h"
#include "mscorlib_System_Collections_SortedList_Enumerator1531140124.h"
#include "mscorlib_System_Collections_Stack1043988394.h"
#include "mscorlib_System_Collections_Stack_Enumerator3156535659.h"
#include "mscorlib_System_Configuration_Assemblies_AssemblyH4147282775.h"
#include "mscorlib_System_Configuration_Assemblies_AssemblyV1223556284.h"
#include "mscorlib_System_Diagnostics_DebuggableAttribute994551506.h"
#include "mscorlib_System_Diagnostics_DebuggableAttribute_De2073970606.h"
#include "mscorlib_System_Diagnostics_DebuggerBrowsableAttri1386379234.h"
#include "mscorlib_System_Diagnostics_DebuggerBrowsableState944457511.h"
#include "mscorlib_System_Diagnostics_DebuggerDisplayAttribu1528914581.h"
#include "mscorlib_System_Diagnostics_DebuggerStepThroughAttr518825354.h"
#include "mscorlib_System_Diagnostics_DebuggerTypeProxyAttrib970972087.h"
#include "mscorlib_System_Diagnostics_StackFrame2050294881.h"
#include "mscorlib_System_Diagnostics_StackTrace2500644597.h"
#include "mscorlib_System_Globalization_Calendar585061108.h"
#include "mscorlib_System_Globalization_CCMath656981594.h"
#include "mscorlib_System_Globalization_CCFixed2263957954.h"
#include "mscorlib_System_Globalization_CCGregorianCalendar852423602.h"
#include "mscorlib_System_Globalization_CompareInfo2310920157.h"
#include "mscorlib_System_Globalization_CompareOptions2829943955.h"
#include "mscorlib_System_Globalization_CultureInfo3500843524.h"
#include "mscorlib_System_Globalization_DateTimeFormatFlags3140910561.h"
#include "mscorlib_System_Globalization_DateTimeFormatInfo2187473504.h"
#include "mscorlib_System_Globalization_DateTimeStyles370343085.h"
#include "mscorlib_System_Globalization_DaylightTime3800227331.h"
#include "mscorlib_System_Globalization_GregorianCalendar3361245568.h"
#include "mscorlib_System_Globalization_GregorianCalendarTyp3080789929.h"
#include "mscorlib_System_Globalization_NumberFormatInfo104580544.h"
#include "mscorlib_System_Globalization_NumberStyles3408984435.h"
#include "mscorlib_System_Globalization_TextInfo3620182823.h"
#include "mscorlib_System_Globalization_TextInfo_Data1649773944.h"
#include "mscorlib_System_Globalization_UnicodeCategory682236799.h"
#include "mscorlib_System_IO_IsolatedStorage_IsolatedStorage2011779685.h"
#include "mscorlib_System_IO_BinaryReader2491843768.h"
#include "mscorlib_System_IO_Directory3318511961.h"
#include "mscorlib_System_IO_DirectoryInfo1934446453.h"
#include "mscorlib_System_IO_DirectoryNotFoundException373523477.h"
#include "mscorlib_System_IO_EndOfStreamException1711658693.h"
#include "mscorlib_System_IO_File1930543328.h"
#include "mscorlib_System_IO_FileAccess4282042064.h"
#include "mscorlib_System_IO_FileAttributes3843045335.h"
#include "mscorlib_System_IO_FileLoadException3198361301.h"
#include "mscorlib_System_IO_FileMode236403845.h"
#include "mscorlib_System_IO_FileNotFoundException4200667904.h"
#include "mscorlib_System_IO_FileOptions3144759768.h"
#include "mscorlib_System_IO_FileShare3362491215.h"
#include "mscorlib_System_IO_FileStream1695958676.h"
#include "mscorlib_System_IO_FileStream_ReadDelegate3184826381.h"
#include "mscorlib_System_IO_FileStream_WriteDelegate489908132.h"
#include "mscorlib_System_IO_FileStreamAsyncResult2252849197.h"
#include "mscorlib_System_IO_FileSystemInfo2360991899.h"
#include "mscorlib_System_IO_IOException2458421087.h"
#include "mscorlib_System_IO_MemoryStream743994179.h"
#include "mscorlib_System_IO_MonoFileType3095218325.h"
#include "mscorlib_System_IO_MonoIO2170088987.h"
#include "mscorlib_System_IO_MonoIOError733012845.h"
#include "mscorlib_System_IO_MonoIOStat1621921065.h"
#include "mscorlib_System_IO_Path41728875.h"
#include "mscorlib_System_IO_PathTooLongException2469314706.h"
#include "mscorlib_System_IO_SearchPattern1107849040.h"
#include "mscorlib_System_IO_SeekOrigin2475945306.h"
#include "mscorlib_System_IO_Stream3255436806.h"
#include "mscorlib_System_IO_NullStream322566869.h"
#include "mscorlib_System_IO_StreamAsyncResult458551667.h"
#include "mscorlib_System_IO_StreamReader2360341767.h"
#include "mscorlib_System_IO_StreamReader_NullStreamReader1178646293.h"
#include "mscorlib_System_IO_StreamWriter3858580635.h"
#include "mscorlib_System_IO_StringReader1480123486.h"
#include "mscorlib_System_IO_TextReader1561828458.h"
#include "mscorlib_System_IO_TextReader_NullTextReader516142577.h"
#include "mscorlib_System_IO_SynchronizedReader498788541.h"
#include "mscorlib_System_IO_TextWriter4027217640.h"
#include "mscorlib_System_IO_TextWriter_NullTextWriter1732518121.h"
#include "mscorlib_System_IO_SynchronizedWriter1348457089.h"
#include "mscorlib_System_IO_UnexceptionalStreamReader683371910.h"
#include "mscorlib_System_IO_UnexceptionalStreamWriter1485343520.h"
#include "mscorlib_System_IO_UnmanagedMemoryStream822875729.h"
#include "mscorlib_System_Reflection_Emit_AssemblyBuilder1646117627.h"
#include "mscorlib_System_Reflection_Emit_ConstructorBuilder700974433.h"
#include "mscorlib_System_Reflection_Emit_DerivedType1016359113.h"
#include "mscorlib_System_Reflection_Emit_ByRefType1587086384.h"
#include "mscorlib_System_Reflection_Emit_EnumBuilder2808714468.h"
#include "mscorlib_System_Reflection_Emit_FieldBuilder2784804005.h"
#include "mscorlib_System_Reflection_Emit_GenericTypeParamet1370236603.h"
#include "mscorlib_System_Reflection_Emit_ILTokenInfo149559338.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator99948092.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelF4090909514.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelD3712112744.h"
#include "mscorlib_System_Reflection_Emit_MethodBuilder644187984.h"
#include "mscorlib_System_Reflection_Emit_MethodToken3991686330.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilder4156028127.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilderTokenG578872653.h"
#include "mscorlib_System_Reflection_Emit_OpCode2247480392.h"
#include "mscorlib_System_Reflection_Emit_OpCodeNames1907134268.h"







#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize200 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize201 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize202 = { sizeof (SortedList_t3004938869), -1, sizeof(SortedList_t3004938869_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable202[6] = 
{
	SortedList_t3004938869_StaticFields::get_offset_of_INITIAL_SIZE_0(),
	SortedList_t3004938869::get_offset_of_inUse_1(),
	SortedList_t3004938869::get_offset_of_modificationCount_2(),
	SortedList_t3004938869::get_offset_of_table_3(),
	SortedList_t3004938869::get_offset_of_comparer_4(),
	SortedList_t3004938869::get_offset_of_defaultCapacity_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize203 = { sizeof (Slot_t2267560602)+ sizeof (Il2CppObject), sizeof(Slot_t2267560602_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable203[2] = 
{
	Slot_t2267560602::get_offset_of_key_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Slot_t2267560602::get_offset_of_value_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize204 = { sizeof (EnumeratorMode_t4029123303)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable204[4] = 
{
	EnumeratorMode_t4029123303::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize205 = { sizeof (Enumerator_t1531140124), -1, sizeof(Enumerator_t1531140124_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable205[9] = 
{
	Enumerator_t1531140124::get_offset_of_host_0(),
	Enumerator_t1531140124::get_offset_of_stamp_1(),
	Enumerator_t1531140124::get_offset_of_pos_2(),
	Enumerator_t1531140124::get_offset_of_size_3(),
	Enumerator_t1531140124::get_offset_of_mode_4(),
	Enumerator_t1531140124::get_offset_of_currentKey_5(),
	Enumerator_t1531140124::get_offset_of_currentValue_6(),
	Enumerator_t1531140124::get_offset_of_invalid_7(),
	Enumerator_t1531140124_StaticFields::get_offset_of_xstr_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize206 = { sizeof (Stack_t1043988394), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable206[5] = 
{
	Stack_t1043988394::get_offset_of_contents_0(),
	Stack_t1043988394::get_offset_of_current_1(),
	Stack_t1043988394::get_offset_of_count_2(),
	Stack_t1043988394::get_offset_of_capacity_3(),
	Stack_t1043988394::get_offset_of_modCount_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize207 = { sizeof (Enumerator_t3156535659), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable207[3] = 
{
	Enumerator_t3156535659::get_offset_of_stack_0(),
	Enumerator_t3156535659::get_offset_of_modCount_1(),
	Enumerator_t3156535659::get_offset_of_current_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize208 = { sizeof (AssemblyHashAlgorithm_t4147282775)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable208[4] = 
{
	AssemblyHashAlgorithm_t4147282775::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize209 = { sizeof (AssemblyVersionCompatibility_t1223556284)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable209[4] = 
{
	AssemblyVersionCompatibility_t1223556284::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize210 = { sizeof (DebuggableAttribute_t994551506), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable210[3] = 
{
	DebuggableAttribute_t994551506::get_offset_of_JITTrackingEnabledFlag_0(),
	DebuggableAttribute_t994551506::get_offset_of_JITOptimizerDisabledFlag_1(),
	DebuggableAttribute_t994551506::get_offset_of_debuggingModes_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize211 = { sizeof (DebuggingModes_t2073970606)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable211[6] = 
{
	DebuggingModes_t2073970606::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize212 = { sizeof (DebuggerBrowsableAttribute_t1386379234), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable212[1] = 
{
	DebuggerBrowsableAttribute_t1386379234::get_offset_of_state_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize213 = { sizeof (DebuggerBrowsableState_t944457511)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable213[4] = 
{
	DebuggerBrowsableState_t944457511::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize214 = { sizeof (DebuggerDisplayAttribute_t1528914581), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable214[3] = 
{
	DebuggerDisplayAttribute_t1528914581::get_offset_of_value_0(),
	DebuggerDisplayAttribute_t1528914581::get_offset_of_type_1(),
	DebuggerDisplayAttribute_t1528914581::get_offset_of_name_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize215 = { sizeof (DebuggerStepThroughAttribute_t518825354), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize216 = { sizeof (DebuggerTypeProxyAttribute_t970972087), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable216[1] = 
{
	DebuggerTypeProxyAttribute_t970972087::get_offset_of_proxy_type_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize217 = { sizeof (StackFrame_t2050294881), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable217[8] = 
{
	0,
	StackFrame_t2050294881::get_offset_of_ilOffset_1(),
	StackFrame_t2050294881::get_offset_of_nativeOffset_2(),
	StackFrame_t2050294881::get_offset_of_methodBase_3(),
	StackFrame_t2050294881::get_offset_of_fileName_4(),
	StackFrame_t2050294881::get_offset_of_lineNumber_5(),
	StackFrame_t2050294881::get_offset_of_columnNumber_6(),
	StackFrame_t2050294881::get_offset_of_internalMethodName_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize218 = { sizeof (StackTrace_t2500644597), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable218[3] = 
{
	0,
	StackTrace_t2500644597::get_offset_of_frames_1(),
	StackTrace_t2500644597::get_offset_of_debug_info_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize219 = { sizeof (Calendar_t585061108), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable219[4] = 
{
	Calendar_t585061108::get_offset_of_m_isReadOnly_0(),
	Calendar_t585061108::get_offset_of_twoDigitYearMax_1(),
	Calendar_t585061108::get_offset_of_M_AbbrEraNames_2(),
	Calendar_t585061108::get_offset_of_M_EraNames_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize220 = { sizeof (CCMath_t656981594), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize221 = { sizeof (CCFixed_t2263957954), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize222 = { sizeof (CCGregorianCalendar_t852423602), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize223 = { sizeof (CompareInfo_t2310920157), -1, sizeof(CompareInfo_t2310920157_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable223[6] = 
{
	CompareInfo_t2310920157_StaticFields::get_offset_of_useManagedCollation_0(),
	CompareInfo_t2310920157::get_offset_of_culture_1(),
	CompareInfo_t2310920157::get_offset_of_icu_name_2(),
	CompareInfo_t2310920157::get_offset_of_collator_3(),
	CompareInfo_t2310920157_StaticFields::get_offset_of_collators_4(),
	CompareInfo_t2310920157_StaticFields::get_offset_of_monitor_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize224 = { sizeof (CompareOptions_t2829943955)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable224[10] = 
{
	CompareOptions_t2829943955::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize225 = { sizeof (CultureInfo_t3500843524), -1, sizeof(CultureInfo_t3500843524_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable225[40] = 
{
	0,
	0,
	0,
	0,
	CultureInfo_t3500843524_StaticFields::get_offset_of_invariant_culture_info_4(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_shared_table_lock_5(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_BootstrapCultureID_6(),
	CultureInfo_t3500843524::get_offset_of_m_isReadOnly_7(),
	CultureInfo_t3500843524::get_offset_of_cultureID_8(),
	CultureInfo_t3500843524::get_offset_of_parent_lcid_9(),
	CultureInfo_t3500843524::get_offset_of_specific_lcid_10(),
	CultureInfo_t3500843524::get_offset_of_datetime_index_11(),
	CultureInfo_t3500843524::get_offset_of_number_index_12(),
	CultureInfo_t3500843524::get_offset_of_m_useUserOverride_13(),
	CultureInfo_t3500843524::get_offset_of_numInfo_14(),
	CultureInfo_t3500843524::get_offset_of_dateTimeInfo_15(),
	CultureInfo_t3500843524::get_offset_of_textInfo_16(),
	CultureInfo_t3500843524::get_offset_of_m_name_17(),
	CultureInfo_t3500843524::get_offset_of_displayname_18(),
	CultureInfo_t3500843524::get_offset_of_englishname_19(),
	CultureInfo_t3500843524::get_offset_of_nativename_20(),
	CultureInfo_t3500843524::get_offset_of_iso3lang_21(),
	CultureInfo_t3500843524::get_offset_of_iso2lang_22(),
	CultureInfo_t3500843524::get_offset_of_icu_name_23(),
	CultureInfo_t3500843524::get_offset_of_win3lang_24(),
	CultureInfo_t3500843524::get_offset_of_territory_25(),
	CultureInfo_t3500843524::get_offset_of_compareInfo_26(),
	CultureInfo_t3500843524::get_offset_of_calendar_data_27(),
	CultureInfo_t3500843524::get_offset_of_textinfo_data_28(),
	CultureInfo_t3500843524::get_offset_of_optional_calendars_29(),
	CultureInfo_t3500843524::get_offset_of_parent_culture_30(),
	CultureInfo_t3500843524::get_offset_of_m_dataItem_31(),
	CultureInfo_t3500843524::get_offset_of_calendar_32(),
	CultureInfo_t3500843524::get_offset_of_constructed_33(),
	CultureInfo_t3500843524::get_offset_of_cached_serialized_form_34(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_MSG_READONLY_35(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_shared_by_number_36(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_shared_by_name_37(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_U3CU3Ef__switchU24map19_38(),
	CultureInfo_t3500843524_StaticFields::get_offset_of_U3CU3Ef__switchU24map1A_39(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize226 = { sizeof (DateTimeFormatFlags_t3140910561)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable226[6] = 
{
	DateTimeFormatFlags_t3140910561::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize227 = { sizeof (DateTimeFormatInfo_t2187473504), -1, sizeof(DateTimeFormatInfo_t2187473504_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable227[58] = 
{
	0,
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_MSG_READONLY_1(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_MSG_ARRAYSIZE_MONTH_2(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_MSG_ARRAYSIZE_DAY_3(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_INVARIANT_ABBREVIATED_DAY_NAMES_4(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_INVARIANT_DAY_NAMES_5(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_INVARIANT_ABBREVIATED_MONTH_NAMES_6(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_INVARIANT_MONTH_NAMES_7(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_INVARIANT_SHORT_DAY_NAMES_8(),
	DateTimeFormatInfo_t2187473504_StaticFields::get_offset_of_theInvariantDateTimeFormatInfo_9(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_isReadOnly_10(),
	DateTimeFormatInfo_t2187473504::get_offset_of_amDesignator_11(),
	DateTimeFormatInfo_t2187473504::get_offset_of_pmDesignator_12(),
	DateTimeFormatInfo_t2187473504::get_offset_of_dateSeparator_13(),
	DateTimeFormatInfo_t2187473504::get_offset_of_timeSeparator_14(),
	DateTimeFormatInfo_t2187473504::get_offset_of_shortDatePattern_15(),
	DateTimeFormatInfo_t2187473504::get_offset_of_longDatePattern_16(),
	DateTimeFormatInfo_t2187473504::get_offset_of_shortTimePattern_17(),
	DateTimeFormatInfo_t2187473504::get_offset_of_longTimePattern_18(),
	DateTimeFormatInfo_t2187473504::get_offset_of_monthDayPattern_19(),
	DateTimeFormatInfo_t2187473504::get_offset_of_yearMonthPattern_20(),
	DateTimeFormatInfo_t2187473504::get_offset_of_fullDateTimePattern_21(),
	DateTimeFormatInfo_t2187473504::get_offset_of__RFC1123Pattern_22(),
	DateTimeFormatInfo_t2187473504::get_offset_of__SortableDateTimePattern_23(),
	DateTimeFormatInfo_t2187473504::get_offset_of__UniversalSortableDateTimePattern_24(),
	DateTimeFormatInfo_t2187473504::get_offset_of_firstDayOfWeek_25(),
	DateTimeFormatInfo_t2187473504::get_offset_of_calendar_26(),
	DateTimeFormatInfo_t2187473504::get_offset_of_calendarWeekRule_27(),
	DateTimeFormatInfo_t2187473504::get_offset_of_abbreviatedDayNames_28(),
	DateTimeFormatInfo_t2187473504::get_offset_of_dayNames_29(),
	DateTimeFormatInfo_t2187473504::get_offset_of_monthNames_30(),
	DateTimeFormatInfo_t2187473504::get_offset_of_abbreviatedMonthNames_31(),
	DateTimeFormatInfo_t2187473504::get_offset_of_allShortDatePatterns_32(),
	DateTimeFormatInfo_t2187473504::get_offset_of_allLongDatePatterns_33(),
	DateTimeFormatInfo_t2187473504::get_offset_of_allShortTimePatterns_34(),
	DateTimeFormatInfo_t2187473504::get_offset_of_allLongTimePatterns_35(),
	DateTimeFormatInfo_t2187473504::get_offset_of_monthDayPatterns_36(),
	DateTimeFormatInfo_t2187473504::get_offset_of_yearMonthPatterns_37(),
	DateTimeFormatInfo_t2187473504::get_offset_of_shortDayNames_38(),
	DateTimeFormatInfo_t2187473504::get_offset_of_nDataItem_39(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_useUserOverride_40(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_isDefaultCalendar_41(),
	DateTimeFormatInfo_t2187473504::get_offset_of_CultureID_42(),
	DateTimeFormatInfo_t2187473504::get_offset_of_bUseCalendarInfo_43(),
	DateTimeFormatInfo_t2187473504::get_offset_of_generalShortTimePattern_44(),
	DateTimeFormatInfo_t2187473504::get_offset_of_generalLongTimePattern_45(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_eraNames_46(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_abbrevEraNames_47(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_abbrevEnglishEraNames_48(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_dateWords_49(),
	DateTimeFormatInfo_t2187473504::get_offset_of_optionalCalendars_50(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_superShortDayNames_51(),
	DateTimeFormatInfo_t2187473504::get_offset_of_genitiveMonthNames_52(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_genitiveAbbreviatedMonthNames_53(),
	DateTimeFormatInfo_t2187473504::get_offset_of_leapYearMonthNames_54(),
	DateTimeFormatInfo_t2187473504::get_offset_of_formatFlags_55(),
	DateTimeFormatInfo_t2187473504::get_offset_of_m_name_56(),
	DateTimeFormatInfo_t2187473504::get_offset_of_all_date_time_patterns_57(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize228 = { sizeof (DateTimeStyles_t370343085)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable228[11] = 
{
	DateTimeStyles_t370343085::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize229 = { sizeof (DaylightTime_t3800227331), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable229[3] = 
{
	DaylightTime_t3800227331::get_offset_of_m_start_0(),
	DaylightTime_t3800227331::get_offset_of_m_end_1(),
	DaylightTime_t3800227331::get_offset_of_m_delta_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize230 = { sizeof (GregorianCalendar_t3361245568), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable230[1] = 
{
	GregorianCalendar_t3361245568::get_offset_of_m_type_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize231 = { sizeof (GregorianCalendarTypes_t3080789929)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable231[7] = 
{
	GregorianCalendarTypes_t3080789929::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize232 = { sizeof (NumberFormatInfo_t104580544), -1, sizeof(NumberFormatInfo_t104580544_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable232[39] = 
{
	NumberFormatInfo_t104580544::get_offset_of_isReadOnly_0(),
	NumberFormatInfo_t104580544::get_offset_of_decimalFormats_1(),
	NumberFormatInfo_t104580544::get_offset_of_currencyFormats_2(),
	NumberFormatInfo_t104580544::get_offset_of_percentFormats_3(),
	NumberFormatInfo_t104580544::get_offset_of_digitPattern_4(),
	NumberFormatInfo_t104580544::get_offset_of_zeroPattern_5(),
	NumberFormatInfo_t104580544::get_offset_of_currencyDecimalDigits_6(),
	NumberFormatInfo_t104580544::get_offset_of_currencyDecimalSeparator_7(),
	NumberFormatInfo_t104580544::get_offset_of_currencyGroupSeparator_8(),
	NumberFormatInfo_t104580544::get_offset_of_currencyGroupSizes_9(),
	NumberFormatInfo_t104580544::get_offset_of_currencyNegativePattern_10(),
	NumberFormatInfo_t104580544::get_offset_of_currencyPositivePattern_11(),
	NumberFormatInfo_t104580544::get_offset_of_currencySymbol_12(),
	NumberFormatInfo_t104580544::get_offset_of_nanSymbol_13(),
	NumberFormatInfo_t104580544::get_offset_of_negativeInfinitySymbol_14(),
	NumberFormatInfo_t104580544::get_offset_of_negativeSign_15(),
	NumberFormatInfo_t104580544::get_offset_of_numberDecimalDigits_16(),
	NumberFormatInfo_t104580544::get_offset_of_numberDecimalSeparator_17(),
	NumberFormatInfo_t104580544::get_offset_of_numberGroupSeparator_18(),
	NumberFormatInfo_t104580544::get_offset_of_numberGroupSizes_19(),
	NumberFormatInfo_t104580544::get_offset_of_numberNegativePattern_20(),
	NumberFormatInfo_t104580544::get_offset_of_percentDecimalDigits_21(),
	NumberFormatInfo_t104580544::get_offset_of_percentDecimalSeparator_22(),
	NumberFormatInfo_t104580544::get_offset_of_percentGroupSeparator_23(),
	NumberFormatInfo_t104580544::get_offset_of_percentGroupSizes_24(),
	NumberFormatInfo_t104580544::get_offset_of_percentNegativePattern_25(),
	NumberFormatInfo_t104580544::get_offset_of_percentPositivePattern_26(),
	NumberFormatInfo_t104580544::get_offset_of_percentSymbol_27(),
	NumberFormatInfo_t104580544::get_offset_of_perMilleSymbol_28(),
	NumberFormatInfo_t104580544::get_offset_of_positiveInfinitySymbol_29(),
	NumberFormatInfo_t104580544::get_offset_of_positiveSign_30(),
	NumberFormatInfo_t104580544::get_offset_of_ansiCurrencySymbol_31(),
	NumberFormatInfo_t104580544::get_offset_of_m_dataItem_32(),
	NumberFormatInfo_t104580544::get_offset_of_m_useUserOverride_33(),
	NumberFormatInfo_t104580544::get_offset_of_validForParseAsNumber_34(),
	NumberFormatInfo_t104580544::get_offset_of_validForParseAsCurrency_35(),
	NumberFormatInfo_t104580544::get_offset_of_nativeDigits_36(),
	NumberFormatInfo_t104580544::get_offset_of_digitSubstitution_37(),
	NumberFormatInfo_t104580544_StaticFields::get_offset_of_invariantNativeDigits_38(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize233 = { sizeof (NumberStyles_t3408984435)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable233[18] = 
{
	NumberStyles_t3408984435::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize234 = { sizeof (TextInfo_t3620182823), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable234[9] = 
{
	TextInfo_t3620182823::get_offset_of_m_listSeparator_0(),
	TextInfo_t3620182823::get_offset_of_m_isReadOnly_1(),
	TextInfo_t3620182823::get_offset_of_customCultureName_2(),
	TextInfo_t3620182823::get_offset_of_m_nDataItem_3(),
	TextInfo_t3620182823::get_offset_of_m_useUserOverride_4(),
	TextInfo_t3620182823::get_offset_of_m_win32LangID_5(),
	TextInfo_t3620182823::get_offset_of_ci_6(),
	TextInfo_t3620182823::get_offset_of_handleDotI_7(),
	TextInfo_t3620182823::get_offset_of_data_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize235 = { sizeof (Data_t1649773944)+ sizeof (Il2CppObject), sizeof(Data_t1649773944 ), 0, 0 };
extern const int32_t g_FieldOffsetTable235[5] = 
{
	Data_t1649773944::get_offset_of_ansi_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Data_t1649773944::get_offset_of_ebcdic_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Data_t1649773944::get_offset_of_mac_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Data_t1649773944::get_offset_of_oem_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Data_t1649773944::get_offset_of_list_sep_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize236 = { sizeof (UnicodeCategory_t682236799)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable236[31] = 
{
	UnicodeCategory_t682236799::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize237 = { sizeof (IsolatedStorageException_t2011779685), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize238 = { sizeof (BinaryReader_t2491843768), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable238[6] = 
{
	BinaryReader_t2491843768::get_offset_of_m_stream_0(),
	BinaryReader_t2491843768::get_offset_of_m_encoding_1(),
	BinaryReader_t2491843768::get_offset_of_m_buffer_2(),
	BinaryReader_t2491843768::get_offset_of_decoder_3(),
	BinaryReader_t2491843768::get_offset_of_charBuffer_4(),
	BinaryReader_t2491843768::get_offset_of_m_disposed_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize239 = { sizeof (Directory_t3318511961), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize240 = { sizeof (DirectoryInfo_t1934446453), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable240[2] = 
{
	DirectoryInfo_t1934446453::get_offset_of_current_5(),
	DirectoryInfo_t1934446453::get_offset_of_parent_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize241 = { sizeof (DirectoryNotFoundException_t373523477), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize242 = { sizeof (EndOfStreamException_t1711658693), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize243 = { sizeof (File_t1930543328), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize244 = { sizeof (FileAccess_t4282042064)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable244[4] = 
{
	FileAccess_t4282042064::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize245 = { sizeof (FileAttributes_t3843045335)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable245[15] = 
{
	FileAttributes_t3843045335::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize246 = { sizeof (FileLoadException_t3198361301), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable246[4] = 
{
	0,
	FileLoadException_t3198361301::get_offset_of_msg_12(),
	FileLoadException_t3198361301::get_offset_of_fileName_13(),
	FileLoadException_t3198361301::get_offset_of_fusionLog_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize247 = { sizeof (FileMode_t236403845)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable247[7] = 
{
	FileMode_t236403845::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize248 = { sizeof (FileNotFoundException_t4200667904), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable248[2] = 
{
	FileNotFoundException_t4200667904::get_offset_of_fileName_11(),
	FileNotFoundException_t4200667904::get_offset_of_fusionLog_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize249 = { sizeof (FileOptions_t3144759768)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable249[8] = 
{
	FileOptions_t3144759768::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize250 = { sizeof (FileShare_t3362491215)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable250[7] = 
{
	FileShare_t3362491215::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize251 = { sizeof (FileStream_t1695958676), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable251[14] = 
{
	FileStream_t1695958676::get_offset_of_access_1(),
	FileStream_t1695958676::get_offset_of_owner_2(),
	FileStream_t1695958676::get_offset_of_async_3(),
	FileStream_t1695958676::get_offset_of_canseek_4(),
	FileStream_t1695958676::get_offset_of_append_startpos_5(),
	FileStream_t1695958676::get_offset_of_anonymous_6(),
	FileStream_t1695958676::get_offset_of_buf_7(),
	FileStream_t1695958676::get_offset_of_buf_size_8(),
	FileStream_t1695958676::get_offset_of_buf_length_9(),
	FileStream_t1695958676::get_offset_of_buf_offset_10(),
	FileStream_t1695958676::get_offset_of_buf_dirty_11(),
	FileStream_t1695958676::get_offset_of_buf_start_12(),
	FileStream_t1695958676::get_offset_of_name_13(),
	FileStream_t1695958676::get_offset_of_handle_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize252 = { sizeof (ReadDelegate_t3184826381), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize253 = { sizeof (WriteDelegate_t489908132), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize254 = { sizeof (FileStreamAsyncResult_t2252849197), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable254[8] = 
{
	FileStreamAsyncResult_t2252849197::get_offset_of_state_0(),
	FileStreamAsyncResult_t2252849197::get_offset_of_completed_1(),
	FileStreamAsyncResult_t2252849197::get_offset_of_wh_2(),
	FileStreamAsyncResult_t2252849197::get_offset_of_cb_3(),
	FileStreamAsyncResult_t2252849197::get_offset_of_Count_4(),
	FileStreamAsyncResult_t2252849197::get_offset_of_OriginalCount_5(),
	FileStreamAsyncResult_t2252849197::get_offset_of_BytesRead_6(),
	FileStreamAsyncResult_t2252849197::get_offset_of_realcb_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize255 = { sizeof (FileSystemInfo_t2360991899), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable255[4] = 
{
	FileSystemInfo_t2360991899::get_offset_of_FullPath_1(),
	FileSystemInfo_t2360991899::get_offset_of_OriginalPath_2(),
	FileSystemInfo_t2360991899::get_offset_of_stat_3(),
	FileSystemInfo_t2360991899::get_offset_of_valid_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize256 = { sizeof (IOException_t2458421087), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize257 = { sizeof (MemoryStream_t743994179), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable257[10] = 
{
	MemoryStream_t743994179::get_offset_of_canWrite_1(),
	MemoryStream_t743994179::get_offset_of_allowGetBuffer_2(),
	MemoryStream_t743994179::get_offset_of_capacity_3(),
	MemoryStream_t743994179::get_offset_of_length_4(),
	MemoryStream_t743994179::get_offset_of_internalBuffer_5(),
	MemoryStream_t743994179::get_offset_of_initialIndex_6(),
	MemoryStream_t743994179::get_offset_of_expandable_7(),
	MemoryStream_t743994179::get_offset_of_streamClosed_8(),
	MemoryStream_t743994179::get_offset_of_position_9(),
	MemoryStream_t743994179::get_offset_of_dirty_bytes_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize258 = { sizeof (MonoFileType_t3095218325)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable258[6] = 
{
	MonoFileType_t3095218325::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize259 = { sizeof (MonoIO_t2170088987), -1, sizeof(MonoIO_t2170088987_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable259[2] = 
{
	MonoIO_t2170088987_StaticFields::get_offset_of_InvalidFileAttributes_0(),
	MonoIO_t2170088987_StaticFields::get_offset_of_InvalidHandle_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize260 = { sizeof (MonoIOError_t733012845)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable260[25] = 
{
	MonoIOError_t733012845::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize261 = { sizeof (MonoIOStat_t1621921065)+ sizeof (Il2CppObject), sizeof(MonoIOStat_t1621921065_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable261[6] = 
{
	MonoIOStat_t1621921065::get_offset_of_Name_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoIOStat_t1621921065::get_offset_of_Attributes_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoIOStat_t1621921065::get_offset_of_Length_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoIOStat_t1621921065::get_offset_of_CreationTime_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoIOStat_t1621921065::get_offset_of_LastAccessTime_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoIOStat_t1621921065::get_offset_of_LastWriteTime_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize262 = { sizeof (Path_t41728875), -1, sizeof(Path_t41728875_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable262[8] = 
{
	Path_t41728875_StaticFields::get_offset_of_InvalidPathChars_0(),
	Path_t41728875_StaticFields::get_offset_of_AltDirectorySeparatorChar_1(),
	Path_t41728875_StaticFields::get_offset_of_DirectorySeparatorChar_2(),
	Path_t41728875_StaticFields::get_offset_of_PathSeparator_3(),
	Path_t41728875_StaticFields::get_offset_of_DirectorySeparatorStr_4(),
	Path_t41728875_StaticFields::get_offset_of_VolumeSeparatorChar_5(),
	Path_t41728875_StaticFields::get_offset_of_PathSeparatorChars_6(),
	Path_t41728875_StaticFields::get_offset_of_dirEqualsVolume_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize263 = { sizeof (PathTooLongException_t2469314706), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize264 = { sizeof (SearchPattern_t1107849040), -1, sizeof(SearchPattern_t1107849040_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable264[2] = 
{
	SearchPattern_t1107849040_StaticFields::get_offset_of_WildcardChars_0(),
	SearchPattern_t1107849040_StaticFields::get_offset_of_InvalidChars_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize265 = { sizeof (SeekOrigin_t2475945306)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable265[4] = 
{
	SeekOrigin_t2475945306::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize266 = { sizeof (Stream_t3255436806), -1, sizeof(Stream_t3255436806_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable266[1] = 
{
	Stream_t3255436806_StaticFields::get_offset_of_Null_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize267 = { sizeof (NullStream_t322566869), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize268 = { sizeof (StreamAsyncResult_t458551667), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable268[6] = 
{
	StreamAsyncResult_t458551667::get_offset_of_state_0(),
	StreamAsyncResult_t458551667::get_offset_of_completed_1(),
	StreamAsyncResult_t458551667::get_offset_of_done_2(),
	StreamAsyncResult_t458551667::get_offset_of_exc_3(),
	StreamAsyncResult_t458551667::get_offset_of_nbytes_4(),
	StreamAsyncResult_t458551667::get_offset_of_wh_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize269 = { sizeof (StreamReader_t2360341767), -1, sizeof(StreamReader_t2360341767_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable269[13] = 
{
	StreamReader_t2360341767::get_offset_of_input_buffer_1(),
	StreamReader_t2360341767::get_offset_of_decoded_buffer_2(),
	StreamReader_t2360341767::get_offset_of_decoded_count_3(),
	StreamReader_t2360341767::get_offset_of_pos_4(),
	StreamReader_t2360341767::get_offset_of_buffer_size_5(),
	StreamReader_t2360341767::get_offset_of_do_checks_6(),
	StreamReader_t2360341767::get_offset_of_encoding_7(),
	StreamReader_t2360341767::get_offset_of_decoder_8(),
	StreamReader_t2360341767::get_offset_of_base_stream_9(),
	StreamReader_t2360341767::get_offset_of_mayBlock_10(),
	StreamReader_t2360341767::get_offset_of_line_builder_11(),
	StreamReader_t2360341767_StaticFields::get_offset_of_Null_12(),
	StreamReader_t2360341767::get_offset_of_foundCR_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize270 = { sizeof (NullStreamReader_t1178646293), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize271 = { sizeof (StreamWriter_t3858580635), -1, sizeof(StreamWriter_t3858580635_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable271[10] = 
{
	StreamWriter_t3858580635::get_offset_of_internalEncoding_2(),
	StreamWriter_t3858580635::get_offset_of_internalStream_3(),
	StreamWriter_t3858580635::get_offset_of_iflush_4(),
	StreamWriter_t3858580635::get_offset_of_byte_buf_5(),
	StreamWriter_t3858580635::get_offset_of_byte_pos_6(),
	StreamWriter_t3858580635::get_offset_of_decode_buf_7(),
	StreamWriter_t3858580635::get_offset_of_decode_pos_8(),
	StreamWriter_t3858580635::get_offset_of_DisposedAlready_9(),
	StreamWriter_t3858580635::get_offset_of_preamble_done_10(),
	StreamWriter_t3858580635_StaticFields::get_offset_of_Null_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize272 = { sizeof (StringReader_t1480123486), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable272[3] = 
{
	StringReader_t1480123486::get_offset_of_source_1(),
	StringReader_t1480123486::get_offset_of_nextChar_2(),
	StringReader_t1480123486::get_offset_of_sourceLength_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize273 = { sizeof (TextReader_t1561828458), -1, sizeof(TextReader_t1561828458_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable273[1] = 
{
	TextReader_t1561828458_StaticFields::get_offset_of_Null_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize274 = { sizeof (NullTextReader_t516142577), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize275 = { sizeof (SynchronizedReader_t498788541), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable275[1] = 
{
	SynchronizedReader_t498788541::get_offset_of_reader_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize276 = { sizeof (TextWriter_t4027217640), -1, sizeof(TextWriter_t4027217640_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable276[2] = 
{
	TextWriter_t4027217640::get_offset_of_CoreNewLine_0(),
	TextWriter_t4027217640_StaticFields::get_offset_of_Null_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize277 = { sizeof (NullTextWriter_t1732518121), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize278 = { sizeof (SynchronizedWriter_t1348457089), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable278[2] = 
{
	SynchronizedWriter_t1348457089::get_offset_of_writer_2(),
	SynchronizedWriter_t1348457089::get_offset_of_neverClose_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize279 = { sizeof (UnexceptionalStreamReader_t683371910), -1, sizeof(UnexceptionalStreamReader_t683371910_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable279[2] = 
{
	UnexceptionalStreamReader_t683371910_StaticFields::get_offset_of_newline_14(),
	UnexceptionalStreamReader_t683371910_StaticFields::get_offset_of_newlineChar_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize280 = { sizeof (UnexceptionalStreamWriter_t1485343520), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize281 = { sizeof (UnmanagedMemoryStream_t822875729), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable281[8] = 
{
	UnmanagedMemoryStream_t822875729::get_offset_of_length_1(),
	UnmanagedMemoryStream_t822875729::get_offset_of_closed_2(),
	UnmanagedMemoryStream_t822875729::get_offset_of_capacity_3(),
	UnmanagedMemoryStream_t822875729::get_offset_of_fileaccess_4(),
	UnmanagedMemoryStream_t822875729::get_offset_of_initial_pointer_5(),
	UnmanagedMemoryStream_t822875729::get_offset_of_initial_position_6(),
	UnmanagedMemoryStream_t822875729::get_offset_of_current_position_7(),
	UnmanagedMemoryStream_t822875729::get_offset_of_Closed_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize282 = { sizeof (AssemblyBuilder_t1646117627), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable282[7] = 
{
	AssemblyBuilder_t1646117627::get_offset_of_modules_10(),
	AssemblyBuilder_t1646117627::get_offset_of_loaded_modules_11(),
	AssemblyBuilder_t1646117627::get_offset_of_corlib_object_type_12(),
	AssemblyBuilder_t1646117627::get_offset_of_corlib_value_type_13(),
	AssemblyBuilder_t1646117627::get_offset_of_corlib_enum_type_14(),
	AssemblyBuilder_t1646117627::get_offset_of_sn_15(),
	AssemblyBuilder_t1646117627::get_offset_of_is_compiler_context_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize283 = { sizeof (ConstructorBuilder_t700974433), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable283[11] = 
{
	ConstructorBuilder_t700974433::get_offset_of_ilgen_2(),
	ConstructorBuilder_t700974433::get_offset_of_parameters_3(),
	ConstructorBuilder_t700974433::get_offset_of_attrs_4(),
	ConstructorBuilder_t700974433::get_offset_of_iattrs_5(),
	ConstructorBuilder_t700974433::get_offset_of_table_idx_6(),
	ConstructorBuilder_t700974433::get_offset_of_call_conv_7(),
	ConstructorBuilder_t700974433::get_offset_of_type_8(),
	ConstructorBuilder_t700974433::get_offset_of_pinfo_9(),
	ConstructorBuilder_t700974433::get_offset_of_init_locals_10(),
	ConstructorBuilder_t700974433::get_offset_of_paramModReq_11(),
	ConstructorBuilder_t700974433::get_offset_of_paramModOpt_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize284 = { sizeof (DerivedType_t1016359113), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable284[1] = 
{
	DerivedType_t1016359113::get_offset_of_elementType_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize285 = { sizeof (ByRefType_t1587086384), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize286 = { sizeof (EnumBuilder_t2808714468), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable286[2] = 
{
	EnumBuilder_t2808714468::get_offset_of__tb_8(),
	EnumBuilder_t2808714468::get_offset_of__underlyingType_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize287 = { sizeof (FieldBuilder_t2784804005), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable287[5] = 
{
	FieldBuilder_t2784804005::get_offset_of_attrs_0(),
	FieldBuilder_t2784804005::get_offset_of_type_1(),
	FieldBuilder_t2784804005::get_offset_of_name_2(),
	FieldBuilder_t2784804005::get_offset_of_typeb_3(),
	FieldBuilder_t2784804005::get_offset_of_marshal_info_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize288 = { sizeof (GenericTypeParameterBuilder_t1370236603), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable288[4] = 
{
	GenericTypeParameterBuilder_t1370236603::get_offset_of_tbuilder_8(),
	GenericTypeParameterBuilder_t1370236603::get_offset_of_mbuilder_9(),
	GenericTypeParameterBuilder_t1370236603::get_offset_of_name_10(),
	GenericTypeParameterBuilder_t1370236603::get_offset_of_base_type_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize289 = { sizeof (ILTokenInfo_t149559338)+ sizeof (Il2CppObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable289[2] = 
{
	ILTokenInfo_t149559338::get_offset_of_member_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ILTokenInfo_t149559338::get_offset_of_code_pos_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize290 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize291 = { sizeof (ILGenerator_t99948092), -1, sizeof(ILGenerator_t99948092_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable291[12] = 
{
	ILGenerator_t99948092_StaticFields::get_offset_of_void_type_0(),
	ILGenerator_t99948092::get_offset_of_code_1(),
	ILGenerator_t99948092::get_offset_of_code_len_2(),
	ILGenerator_t99948092::get_offset_of_max_stack_3(),
	ILGenerator_t99948092::get_offset_of_cur_stack_4(),
	ILGenerator_t99948092::get_offset_of_num_token_fixups_5(),
	ILGenerator_t99948092::get_offset_of_token_fixups_6(),
	ILGenerator_t99948092::get_offset_of_labels_7(),
	ILGenerator_t99948092::get_offset_of_fixups_8(),
	ILGenerator_t99948092::get_offset_of_num_fixups_9(),
	ILGenerator_t99948092::get_offset_of_module_10(),
	ILGenerator_t99948092::get_offset_of_token_gen_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize292 = { sizeof (LabelFixup_t4090909514)+ sizeof (Il2CppObject), sizeof(LabelFixup_t4090909514 ), 0, 0 };
extern const int32_t g_FieldOffsetTable292[3] = 
{
	LabelFixup_t4090909514::get_offset_of_offset_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	LabelFixup_t4090909514::get_offset_of_pos_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	LabelFixup_t4090909514::get_offset_of_label_idx_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize293 = { sizeof (LabelData_t3712112744)+ sizeof (Il2CppObject), sizeof(LabelData_t3712112744 ), 0, 0 };
extern const int32_t g_FieldOffsetTable293[2] = 
{
	LabelData_t3712112744::get_offset_of_addr_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	LabelData_t3712112744::get_offset_of_maxStack_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize294 = { sizeof (MethodBuilder_t644187984), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable294[12] = 
{
	MethodBuilder_t644187984::get_offset_of_rtype_0(),
	MethodBuilder_t644187984::get_offset_of_parameters_1(),
	MethodBuilder_t644187984::get_offset_of_attrs_2(),
	MethodBuilder_t644187984::get_offset_of_iattrs_3(),
	MethodBuilder_t644187984::get_offset_of_name_4(),
	MethodBuilder_t644187984::get_offset_of_code_5(),
	MethodBuilder_t644187984::get_offset_of_ilgen_6(),
	MethodBuilder_t644187984::get_offset_of_type_7(),
	MethodBuilder_t644187984::get_offset_of_pinfo_8(),
	MethodBuilder_t644187984::get_offset_of_override_method_9(),
	MethodBuilder_t644187984::get_offset_of_call_conv_10(),
	MethodBuilder_t644187984::get_offset_of_generic_params_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize295 = { sizeof (MethodToken_t3991686330)+ sizeof (Il2CppObject), sizeof(MethodToken_t3991686330 ), sizeof(MethodToken_t3991686330_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable295[2] = 
{
	MethodToken_t3991686330::get_offset_of_tokValue_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MethodToken_t3991686330_StaticFields::get_offset_of_Empty_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize296 = { sizeof (ModuleBuilder_t4156028127), -1, sizeof(ModuleBuilder_t4156028127_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable296[6] = 
{
	ModuleBuilder_t4156028127::get_offset_of_num_types_10(),
	ModuleBuilder_t4156028127::get_offset_of_types_11(),
	ModuleBuilder_t4156028127::get_offset_of_assemblyb_12(),
	ModuleBuilder_t4156028127::get_offset_of_table_indexes_13(),
	ModuleBuilder_t4156028127::get_offset_of_token_gen_14(),
	ModuleBuilder_t4156028127_StaticFields::get_offset_of_type_modifiers_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize297 = { sizeof (ModuleBuilderTokenGenerator_t578872653), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable297[1] = 
{
	ModuleBuilderTokenGenerator_t578872653::get_offset_of_mb_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize298 = { sizeof (OpCode_t2247480392)+ sizeof (Il2CppObject), sizeof(OpCode_t2247480392 ), 0, 0 };
extern const int32_t g_FieldOffsetTable298[8] = 
{
	OpCode_t2247480392::get_offset_of_op1_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_op2_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_push_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_pop_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_size_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_type_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_args_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OpCode_t2247480392::get_offset_of_flow_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize299 = { sizeof (OpCodeNames_t1907134268), -1, sizeof(OpCodeNames_t1907134268_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable299[1] = 
{
	OpCodeNames_t1907134268_StaticFields::get_offset_of_names_0(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
